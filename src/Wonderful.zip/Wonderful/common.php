<?PHP

$algos = array (
    'md5',
    'gost',
    'sha384',
    'sha512',
);

$local_salt = file_get_contents('salt.txt');
