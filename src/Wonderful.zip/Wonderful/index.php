<?php

include_once 'common.php';
include_once 'funcs.php';

include_once 'db.inc';

if (isset($_POST, $_POST['login'], $_POST['password']))
{
    if (hash_check($_POST['login'], $_POST['password']))
    {
        echo 'Success';
        header('Location: http://admin_tgsEFYZfpHcLXEWk.hashrunner.zone');
        exit();
    }
}
?><h1>It works!</h1>

