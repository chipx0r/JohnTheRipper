<?php

include_once('common.php');
include_once('db.inc');

define('UNICODE', 1 << 0);
define('PERMUTE_L', 1 << 1);
define('PERMUTE_P', 1 << 2);
define('HASH_L', 1 << 3);
define('HASH_P', 1 << 4);
define('POS', 1 << 5);
define('DO_XOR', 1 << 6);
define('HMAC', 1 << 7);


function hash_step($password, $salt, $mode, $xor_pos, $hash_type)
{
    $mode = intval($mode);

    if ($mode & UNICODE) $password = mb_convert_encoding($password, 'UTF-8');

    if ($mode & PERMUTE_L) $password = permute($password);
    if ($mode & PERMUTE_P) $salt = permute($salt);

    if ($mode & HASH_P) $password = hash($hash_type, $password, true);
    if ($mode & HASH_L) $salt = hash($hash_type, $salt, true);

    if ($mode & POS) list($p1, $p2) = array($password, $salt);
    else list($p1, $p2) = array($salt, $password);

    if ($mode & HMAC)
        $hashed = hash_hmac($hash_type, $p1, $p2, true);
    else
    {
        $tmp = $p1.$p2;
        if ($mode & DO_XOR) $tmp = do_xor($tmp, $xor_pos);
        $hashed = hash($hash_type, $tmp, true);
    }

    return sprintf('%s:%s:%s', $hash_type, strval($xor_pos), bin2hex(chr($mode).$hashed));
}

function hash_check($login, $password)
{
    global $db_hash;
    if (array_key_exists($login, $db_hash)) {
        $user = $db_hash[$login];
    } else
    {
        return False;
    }

    list($hash_type, $xor_pos, $hash) = explode(':', $user['hash']);

    $xor_pos = intval($xor_pos);

    $mode = ord(hex2bin($hash)[0]);

    if ($user['hash'] === hash_step($password, $user['salt'], $mode, $xor_pos, $hash_type))
    {
        return True;
    } else
    {
        return false;
    }

}

function permute($string)
{
    $string = str_pad($string, 64, chr(strlen($string)));
    $out_string = implode(array($string[58], $string[50], $string[42], $string[34], $string[26], $string[18], $string[10], $string[2], $string[60], $string[52], $string[44], $string[36], $string[28], $string[20], $string[12], $string[4], $string[62], $string[54], $string[46], $string[38], $string[30], $string[22], $string[14], $string[6], $string[64], $string[56], $string[48], $string[40], $string[32], $string[24], $string[16], $string[8], $string[57], $string[49], $string[41], $string[33], $string[25], $string[17], $string[9], $string[1], $string[59], $string[51], $string[43], $string[35], $string[27], $string[19], $string[11], $string[3], $string[61], $string[53], $string[45], $string[37], $string[29], $string[21], $string[13], $string[5], $string[63], $string[55], $string[47], $string[39], $string[31], $string[23], $string[15], $string[7]));
    return $out_string;
}

function do_xor($string, $xor_pos)
{
    $xor_stream = file_get_contents('salt.txt');

    $string_arr = str_split($string);
    $xor_arr = str_split(substr($xor_stream, 16 * $xor_pos, 16)); // Or (16 * xor_pos * ord($string[0])) & 0xFFFF0

    for ($i = 0; $i < 16; ++$i)
    {
        $string_arr[$i] = chr(
            ord($string_arr[$i]) ^ ord($xor_arr[$i])
        );
    }

    return implode($string);
}

function get_real_rand()
{
    if(function_exists('openssl_random_pseudo_bytes'))
        $a = abs(hexdec(bin2hex(openssl_random_pseudo_bytes(4))) & 0xFFFFFFFF);
    else
        $a = mt_rand();
    return $a;
}

function gen_salt($length=16)
{
    $possibilities = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $result = array();
    for ($i=0; $i < $length; ++$i)
    {
        $result[] = $possibilities[get_real_rand() % strlen($possibilities)];
    }
    return implode('', $result);
}


function gen_hash_type()
{
    global $algos;
    return $algos[array_rand($algos, 1)];
}


